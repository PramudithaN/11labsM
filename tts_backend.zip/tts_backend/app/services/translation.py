import httpx
from typing import Dict, List
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from app.config import get_settings

settings = get_settings()


class TranslationError(Exception):
    pass


# ── DeepL ────────────────────────────────────────────────────────────────────

DEEPL_LANGUAGE_MAP = {
    "en": "EN-US", "fr": "FR", "es": "ES", "de": "DE",
    "it": "IT", "pt": "PT-PT", "nl": "NL", "pl": "PL",
    "ru": "RU", "ja": "JA", "zh": "ZH", "ar": "AR",
    "ko": "KO", "sv": "SV", "da": "DA", "fi": "FI",
    "nb": "NB", "tr": "TR", "cs": "CS", "ro": "RO",
}


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type(httpx.HTTPError),
)
async def _translate_deepl(text: str, target_lang: str) -> str:
    deepl_lang = DEEPL_LANGUAGE_MAP.get(target_lang.lower(), target_lang.upper())
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api-free.deepl.com/v2/translate",
            headers={"Authorization": f"DeepL-Auth-Key {settings.deepl_api_key}"},
            json={"text": [text], "target_lang": deepl_lang},
        )
        resp.raise_for_status()
        data = resp.json()
        return data["translations"][0]["text"]


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type(httpx.HTTPError),
)
async def _translate_google(text: str, target_lang: str) -> str:
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://translation.googleapis.com/language/translate/v2",
            params={"key": settings.google_translate_api_key},
            json={"q": text, "target": target_lang, "format": "text"},
        )
        resp.raise_for_status()
        data = resp.json()
        return data["data"]["translations"][0]["translatedText"]


# ── Public interface ──────────────────────────────────────────────────────────

async def translate_to_all(text: str, languages: List[str]) -> Dict[str, str]:
    """
    Translate `text` into each of the requested languages.
    Returns a dict like {"en": "Hello", "fr": "Bonjour", "es": "Hola"}.
    Source language is detected automatically by the provider.
    """
    results: Dict[str, str] = {}
    provider = settings.translation_provider.lower()

    for lang in languages:
        try:
            if provider == "deepl":
                translated = await _translate_deepl(text, lang)
            elif provider == "google":
                translated = await _translate_google(text, lang)
            else:
                raise TranslationError(f"Unknown translation provider: {provider}")
            results[lang] = translated
        except Exception as exc:
            raise TranslationError(f"Failed to translate to '{lang}': {exc}") from exc

    return results
